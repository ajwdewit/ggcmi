gfortran -fPIC -O3 -c *.for
ar rv libttutil.a *.o
